 # Práctica 1

Practica 1 de CSAAI, en las instruccicones de la práctica se nos indicaba que se podia hacer de un personaje ficticio, por ello he decidido hacerlo de el Profesor Layton una de mis sagas de videojuegos favorita de la infancia.